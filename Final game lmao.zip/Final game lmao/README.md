# chess_template
template for a chess game

Andrew is currently at: 1100 SR. Tier: BRONZE
